import {atom} from 'recoil';

export const PathAtom = atom({
    key : "PathAtom",
    default : '/HomePage'
})